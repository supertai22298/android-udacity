package com.example.familyapp.viewmodel;

import android.content.Context;

import com.example.familyapp.viewmodel.base.BaseViewModel;

public class MainViewModel extends BaseViewModel {
    public MainViewModel(Context context) {
        super(context);
    }
}
