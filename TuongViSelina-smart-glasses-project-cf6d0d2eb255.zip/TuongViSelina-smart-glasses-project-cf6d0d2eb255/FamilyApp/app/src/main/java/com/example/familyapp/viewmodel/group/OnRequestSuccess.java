package com.example.familyapp.viewmodel.group;

public interface OnRequestSuccess<T> {
    void onSuccess(T data);
}
